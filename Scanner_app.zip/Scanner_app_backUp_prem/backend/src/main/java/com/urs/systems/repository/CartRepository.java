package com.urs.systems.repository;


import com.urs.systems.dto.CartDTO;
import com.urs.systems.model.Cart;


public interface CartRepository  {

	public Cart getNewCart(int id);	
	
	public CartDTO updateCart(Cart cart);
	
	public CartDTO updateCartNN(Cart cart);
	
	public CartDTO getCartById(int cartId);
}
