package com.urs.systems.repository;

import com.urs.systems.model.User;

public interface UserRepository {

	
	public User findUserByUsername(String username);
	
	public User getUserById(int id);

}
