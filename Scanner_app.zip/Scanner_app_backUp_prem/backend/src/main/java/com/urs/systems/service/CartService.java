package com.urs.systems.service;

import com.urs.systems.dto.CartDTO;
import com.urs.systems.dto.ProductDTO;
import com.urs.systems.dto.UserDTO;
import com.urs.systems.model.User;

public interface CartService {
	
	public CartDTO getCartById(int cartId);

	public CartDTO updateCart(CartDTO cart);
	
	public CartDTO updateCartNN(CartDTO cart);

}
