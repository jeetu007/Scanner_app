package com.urs.systems.repository;


import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.urs.systems.model.User;


@Repository("UserRepository")
@Transactional
public class UserRepositoryImp extends AbstractDao<Integer, User> implements UserRepository {

	@Autowired
	private SessionFactory sessionFactory;
	
	@Autowired
	ModelMapper modelmapper;
	
	@Override
	public User findUserByUsername(String username) {
		Session ss = sessionFactory.getCurrentSession();
		Query query = ss.createQuery("from User u where u.username=:username or u.email=:email");
		query.setString("username",username);
		query.setString("email",username);
		List<User> list =(List<User>)query.list();
		User obj = null;
		if(list.size()>0) {
			obj = (User)list.get(0);
		}
		return  obj;
	}
	
	@Override
	public User getUserById(int id) {
		return (User)sessionFactory.getCurrentSession().get(User.class, id);
	}

}
