package com.urs.systems.repository;


import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.sql.Date;
import org.apache.commons.beanutils.PropertyUtils;
import org.hibernate.SessionFactory;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.urs.systems.dto.CartDTO;
import com.urs.systems.model.Cart;
import com.urs.systems.model.User;
import com.urs.systems.repository.CartRepository;
import com.urs.systems.service.JSONService;


@Repository("CartRepository")
@Transactional
public class CartRepositoryImp implements CartRepository {

	@Autowired
	private SessionFactory sessionFactory;
	
	@Autowired
	private UserRepository userRepository;
	
	@Autowired
	private ModelMapper modelmapper;
	
	@Autowired
	private JSONService jsonService;
	
	private final String cartStatus = "Pending";
	
	@Override
	public Cart getNewCart(int id) {
		User user = userRepository.getUserById(id);
		if(user != null) {
			for(Cart cart : user.getCarts()) {
				if(cartStatus.equalsIgnoreCase(cart.getStatus())) {
					return cart;
				}
			}
			Cart cart = new Cart();
			cart.setStatus(cartStatus);
			cart.setTotalPrice(0d);
			cart.setTotalQuantity(0);
			cart.setDiscount(0d);
			cart.setTax(0d);
			cart.setDeliveryCharge(0d);
			cart.setUser(user);
			cart.setCreatedOn(new Date(System.currentTimeMillis()));
			cart.setModifiedOn(new Date(System.currentTimeMillis()));
			sessionFactory.getCurrentSession().save(cart);
			return cart;
		}
		return null;
	}
	
	@Override
	public CartDTO updateCart(Cart cart) {
		cart.setModifiedOn(new Date(System.currentTimeMillis()));
		sessionFactory.getCurrentSession().update(cart);
		return getCartById(cart.getCartId());
	}
	
	@Override
	public CartDTO updateCartNN(Cart cart) {
		Cart exitingCart = (Cart)sessionFactory.getCurrentSession().get(Cart.class, cart.getCartId());
		cart = jsonService.calculateUsingJsonString(cart);
		//String qr_code = jsonService.matchJSONString(exitingCart.getQrCode(), cart.getQrCode());
		
		Class<?> className = cart.getClass();
		for (Field field : className.getDeclaredFields()) {
		 try {
				Object temp = PropertyUtils.getProperty(cart, field.getName());
				if (temp != null && !temp.toString().equals("cartId")) {
					PropertyUtils.setProperty(exitingCart, field.getName(), temp);
				}
			} catch (IllegalAccessException e) {
				e.printStackTrace();
			} catch (InvocationTargetException e) {
				e.printStackTrace();
			} catch (NoSuchMethodException e) {
				//e.printStackTrace();
			} catch (Exception e){
				e.printStackTrace();
			} 
		}
		//exitingCart.setQrCode(qr_code);
		exitingCart.setModifiedOn(new Date(System.currentTimeMillis()));
		sessionFactory.getCurrentSession().update(exitingCart);
		
		if(cartStatus.equalsIgnoreCase(exitingCart.getStatus())) {
			return modelmapper.map(exitingCart, CartDTO.class);
		}
		
		return modelmapper.map(getNewCart(exitingCart.getUser().getUserId()), CartDTO.class);
	}
	
	public CartDTO getCartById(int cartId) {
		Cart cart = (Cart)sessionFactory.getCurrentSession().get(Cart.class, cartId);
		if(cart == null)
			return null;
		return modelmapper.map(cart, CartDTO.class);		
	}
	
}
