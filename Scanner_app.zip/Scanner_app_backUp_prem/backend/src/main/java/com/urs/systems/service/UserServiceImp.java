package com.urs.systems.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.urs.systems.model.User;
import com.urs.systems.repository.UserRepository;

@Service
public class UserServiceImp implements UserService {

	@Autowired
	UserRepository userRepository;

	public User findUserByUsername(String username) {
		return userRepository.findUserByUsername(username);
	}
}
