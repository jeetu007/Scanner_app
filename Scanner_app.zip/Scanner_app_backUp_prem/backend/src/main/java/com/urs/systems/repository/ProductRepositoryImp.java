package com.urs.systems.repository;


import java.sql.Date;
import java.util.ArrayList;
import java.util.List;

import org.hibernate.Query;
import org.hibernate.SessionFactory;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.urs.systems.dto.ProductDTO;
import com.urs.systems.dto.UserProfileDTO;
import com.urs.systems.model.Cart;
import com.urs.systems.model.Product;
import com.urs.systems.model.User;
import com.urs.systems.model.UserProfile;
import com.urs.systems.repository.CartRepository;


@Repository("ProductRepository")
@Transactional
public class ProductRepositoryImp implements ProductRepository {

	@Autowired
	private SessionFactory sessionFactory;
	
	@Autowired
	ModelMapper modelmapper;
	
	@Override
	public ProductDTO getProductById(int pid) {
		Product product = (Product)sessionFactory.getCurrentSession().get(Product.class, pid);
		if(product == null) {
			return null;
		}		
		return modelmapper.map(product, ProductDTO.class);
	}
	
	@Override
	public ProductDTO getProductByBarcode(String barcode) {
		Query query = sessionFactory.getCurrentSession().createQuery("from Product p where p.barcode=:barcode");
		query.setString("barcode",barcode);
		List<Product> products = (List<Product>)query.list();
		if(products.size()<1) {
			return null;
		}
		ProductDTO product = modelmapper.map(products.get(0), ProductDTO.class);		
		return product;
	}
	
}
