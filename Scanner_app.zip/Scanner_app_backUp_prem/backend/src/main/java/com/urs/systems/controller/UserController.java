package com.urs.systems.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.oauth2.common.OAuth2AccessToken;
import org.springframework.security.oauth2.provider.token.TokenStore;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.urs.systems.service.UserService;

@RestController
public class UserController {

	@Autowired
	UserService userService;
	
	@Autowired
	TokenStore tokenStore;

	@RequestMapping("/vk")
	public ResponseEntity<String> restAPI() {
		return new ResponseEntity<String>("REST API", HttpStatus.OK);
	}
	
	@RequestMapping(value = "/all/logout", method = RequestMethod.POST, produces = MediaType.TEXT_PLAIN_VALUE)
	public ResponseEntity<String> userLogOut(@RequestParam("access_token") String accessToken) {

		String message = "";

		try {

			OAuth2AccessToken oauth2AccessToken = tokenStore.readAccessToken(accessToken);

			if (oauth2AccessToken == null || oauth2AccessToken.equals(null)) {
				return new ResponseEntity<String>("No such token exists !", HttpStatus.NOT_FOUND);
			}

			tokenStore.removeAccessToken(oauth2AccessToken);

			message = "You have been logged out.";
			System.out.println("You have been logged out.");

			return new ResponseEntity<String>(message, HttpStatus.OK);

		} catch (Exception e) {
			message = "Error in token store.";
			System.out.println("Error in token store.");
			return new ResponseEntity<String>(message, HttpStatus.NOT_ACCEPTABLE);
		}

	}

}