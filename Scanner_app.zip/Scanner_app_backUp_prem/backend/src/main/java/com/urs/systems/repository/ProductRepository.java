package com.urs.systems.repository;


import com.urs.systems.dto.ProductDTO;


public interface ProductRepository  {

	public ProductDTO getProductByBarcode(String barcode);
	
	public ProductDTO getProductById(int pid);
	
}
