package com.urs.systems.service;

import javax.json.Json;
import javax.json.JsonArray;
import javax.json.JsonArrayBuilder;
import javax.json.JsonObject;
import javax.json.JsonObjectBuilder;
import javax.json.JsonReader;
import org.apache.commons.io.IOUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.urs.systems.dto.CartDTO;
import com.urs.systems.dto.ProductDTO;
import com.urs.systems.model.Cart;
import com.urs.systems.repository.ProductRepository;

@Service
public class JSONService {
	
	@Autowired
	ProductRepository productRepository;
	
	public Cart calculateUsingJsonString(Cart cart) {
		if(cart.getQrCode() == null || cart.getQrCode().trim().isEmpty()) 
			return cart;
		try {
			
			JsonReader reader = Json.createReader(IOUtils.toInputStream(cart.getQrCode().replace("'", "\""), "UTF-8"));
			JsonObject obj = reader.readObject();
			
			JsonArray values = obj.getJsonArray("values");
			if(values != null) {
				double totalPrice = 0;
				int totalQuantity = 0;
				for (JsonObject result : values.getValuesAs(JsonObject.class)) {
					ProductDTO prodcut;
					if(result.getString("barcode") != null && !result.getString("barcode").isEmpty()) {
						prodcut = productRepository.getProductByBarcode(result.getString("barcode"));
					} else  {
						prodcut = productRepository.getProductById(result.getInt("product_id"));
					}
					totalPrice += prodcut.getPrice() *  result.getInt("quantity");
					totalQuantity += result.getInt("quantity");
				}
				cart.setTotalPrice(totalPrice);
				cart.setTotalQuantity(totalQuantity);
				cart.setDiscount(20.20);
				cart.setTax(10.11);
				cart.setDeliveryCharge(139.00);
			}			
		} catch(Exception e) {
			e.printStackTrace();
			return cart;
		} 
		return cart;
	}
	
	
	public String matchJSONString(String oldJsonString, String newJsonString) {
		if(oldJsonString == null || oldJsonString.trim().isEmpty())
			return newJsonString; 
		if(newJsonString == null || newJsonString.trim().isEmpty())
			return oldJsonString;
		
		JsonObject oldJSON = null;
		JsonObject newJSON = null;
		
		JsonObjectBuilder resultJSON = Json.createObjectBuilder();
		JsonArrayBuilder resultJSONArray = Json.createArrayBuilder();
		
		try {
			JsonReader firstReader = Json.createReader(IOUtils.toInputStream(oldJsonString.replace("'", "\""), "UTF-8"));
			JsonReader secondReader = Json.createReader(IOUtils.toInputStream(newJsonString.replace("'", "\""), "UTF-8"));
			
			oldJSON = firstReader.readObject();
			newJSON = secondReader.readObject();
			
			if(newJSON.containsKey("code_type")) {
				if(newJSON.get("code_type") != null)
					resultJSON.add("code_type", newJSON.getString("code_type"));
			} else {
				if(oldJSON.get("code_type") != null)
					resultJSON.add("code_type", oldJSON.getString("code_type"));
			}
				
			if(newJSON.containsKey("delimiter")) {
				if(newJSON.get("delimiter") != null)
					resultJSON.add("delimiter", newJSON.getString("delimiter"));
			} else {
				if(oldJSON.get("delimiter") != null)
					resultJSON.add("delimiter", oldJSON.getString("delimiter"));
			}
			
			JsonArray oldJsonArray = oldJSON.getJsonArray("values");
			JsonArray newJsonArray = newJSON.getJsonArray("values");
			
			boolean loopStatus = true;
			if(oldJsonArray != null && newJsonArray != null && loopStatus) {
				for (JsonObject oldResult : newJsonArray.getValuesAs(JsonObject.class)) {
					boolean status = false;
					JsonObject obj1 = null;
					JsonObject obj2 = null;
					for (JsonObject newResult : oldJsonArray.getValuesAs(JsonObject.class)) {
						if(oldResult.getString("barcode").equalsIgnoreCase(newResult.getString("barcode")) && oldResult.getInt("product_id") == newResult.getInt("product_id")) {
							resultJSONArray.add(newResult);
						} else {
							status = true;
							obj1 = oldResult;
							obj2 = newResult;
						}
					}
					if(status) {
						resultJSONArray.add(obj1);
						resultJSONArray.add(obj2);
					}
				}
				resultJSONArray.build();
				resultJSON.add("values", resultJSONArray);
				loopStatus = false;
			}
			
			if(oldJsonArray != null && newJsonArray != null && loopStatus) {
				for (JsonObject oldResult : oldJsonArray.getValuesAs(JsonObject.class)) {
					boolean status = false;
					JsonObject obj1 = null;
					JsonObject obj2 = null;
					for (JsonObject newResult : newJsonArray.getValuesAs(JsonObject.class)) {
						if(oldResult.getString("barcode").equalsIgnoreCase(newResult.getString("barcode")) && oldResult.getInt("product_id") == newResult.getInt("product_id")) {
							resultJSONArray.add(newResult);
						} else {
							status = true;
							obj1 = oldResult;
							obj2 = newResult;
						}
					}
					if(status) {
						resultJSONArray.add(obj1);
						resultJSONArray.add(obj2);
					}
				}
				resultJSONArray.build();
				resultJSON.add("values", resultJSONArray);
			} else if(oldJsonArray == null && newJsonArray != null) {
				resultJSON.add("values", newJsonArray);
				
			} else if(oldJsonArray != null && newJsonArray == null) {
				resultJSON.add("values", oldJsonArray);
			}
				
			
		
			System.out.println(resultJSON.build().toString());
		} catch(Exception e) {e.printStackTrace();}
		
		return resultJSON.build().toString();
	}
	
}
