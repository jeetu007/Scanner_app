package com.urs.systems.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.urs.systems.dto.ProductDTO;
import com.urs.systems.repository.ProductRepository;
import com.urs.systems.service.ProductService;
import com.urs.systems.service.UserService;

@RestController
public class ProductController {
	
	@Autowired
	ProductService productService;
	
	@RequestMapping(value = "/user/product/{barcode}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<ProductDTO> getProducts(@PathVariable("barcode") String barcode) {
		ProductDTO product = productService.getProductByBarcode(barcode);
		if (product == null) 
			return new ResponseEntity<ProductDTO>(HttpStatus.NOT_FOUND);
		return new ResponseEntity<ProductDTO>(product, HttpStatus.OK);
	}

}