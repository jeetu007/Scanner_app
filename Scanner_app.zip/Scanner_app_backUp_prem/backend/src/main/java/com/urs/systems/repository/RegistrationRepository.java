package com.urs.systems.repository;


import java.sql.Date;
import java.util.ArrayList;
import java.util.List;

import org.hibernate.Query;
import org.hibernate.SessionFactory;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.urs.systems.dto.UserDTO;
import com.urs.systems.dto.UserProfileDTO;
import com.urs.systems.model.User;
import com.urs.systems.model.UserProfile;


@Repository
@Transactional
public class RegistrationRepository  {

	@Autowired
	private SessionFactory sessionFactory;
	
	@Autowired
	ModelMapper modelmapper;
	
	public boolean registration(UserDTO user) {
		try {
			Query query = sessionFactory.getCurrentSession().createQuery("from User u where u.email=:email or u.username=:username");
			query.setString("username",user.getUsername());
			query.setString("email",user.getEmail());
			if(query.list().size()>0) {
				return false;
			}
			
			User obj = modelmapper.map(user, User.class);
			
			List<UserProfile> profiles = new ArrayList<UserProfile>();
			
			for(UserProfileDTO profileDTO : user.getUserProfiles()) {
				UserProfile profile = new UserProfile();
				profile.setType(profileDTO.getType());
				profile.setCreatedOn(new Date(System.currentTimeMillis()));
				profile.setModifiedOn(new Date(System.currentTimeMillis()));
				sessionFactory.getCurrentSession().save(profile);
				profiles.add(profile);
			}
			
			obj.setUserProfiles(profiles);
			
			obj.setStatus("INACTIVE");
			obj.setCreatedOn(new Date(System.currentTimeMillis()));
			obj.setModifiedOn(new Date(System.currentTimeMillis()));
			
			sessionFactory.getCurrentSession().save(obj);
			
		} catch(Exception e) {return false;}
		return true;
	}
	
}
