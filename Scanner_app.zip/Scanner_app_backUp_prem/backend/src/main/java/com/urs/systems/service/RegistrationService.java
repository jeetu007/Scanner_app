package com.urs.systems.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.urs.systems.dto.UserDTO;
import com.urs.systems.repository.RegistrationRepository;

@Service
public class RegistrationService {
	
	@Autowired
	RegistrationRepository registrationRepository;
	
	public boolean registration(UserDTO user) {
		return registrationRepository.registration(user);
	}
	
}
