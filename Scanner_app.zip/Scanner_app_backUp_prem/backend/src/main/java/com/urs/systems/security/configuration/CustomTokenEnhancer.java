package com.urs.systems.security.configuration;

import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.oauth2.common.DefaultOAuth2AccessToken;
import org.springframework.security.oauth2.common.OAuth2AccessToken;
import org.springframework.security.oauth2.provider.OAuth2Authentication;
import org.springframework.security.oauth2.provider.token.TokenEnhancer;

import com.urs.systems.model.User;
import com.urs.systems.repository.CartRepository;
import com.urs.systems.service.UserServiceImp;

public class CustomTokenEnhancer implements TokenEnhancer {
	
	@Autowired
	UserServiceImp userService;
	
	@Autowired
	CartRepository cartRepository;
	
	public OAuth2AccessToken enhance(OAuth2AccessToken accessToken, OAuth2Authentication authentication) {
		final Map<String, Object> additionalInfo = new HashMap<String, Object>();

		String authorities = "";
		for (GrantedAuthority role : authentication.getAuthorities()) {
			authorities = "" + role;
		}

		User user = userService.findUserByUsername(authentication.getName());
		
		additionalInfo.put("uid", user.getUserId());
		additionalInfo.put("username",  user.getFirstName() + " " + user.getLastName());
		additionalInfo.put("authorities", authorities.substring(5));
		additionalInfo.put("cartId", cartRepository.getNewCart(user.getUserId()).getCartId());

		((DefaultOAuth2AccessToken) accessToken).setAdditionalInformation(additionalInfo);

		return accessToken;
	}
}
