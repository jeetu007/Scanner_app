package com.urs.systems.service;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.urs.systems.dto.CartDTO;
import com.urs.systems.dto.ProductDTO;
import com.urs.systems.model.Cart;
import com.urs.systems.repository.CartRepository;

@Service("CartService")
public class CartServiceImp implements CartService {

	@Autowired
	CartRepository cartRepository;
	
	@Autowired
	ModelMapper modelmapper;
	
	@Override
	public CartDTO getCartById(int cartId) {
		return cartRepository.getCartById(cartId);
	}

	@Override
	public CartDTO updateCart(CartDTO cart) {
		Cart obj = modelmapper.map(cart, Cart.class);
		return cartRepository.updateCart(obj);
	}
	
	@Override
	public CartDTO updateCartNN(CartDTO cart) {
		Cart obj = modelmapper.map(cart, Cart.class);
		return cartRepository.updateCartNN(obj);
	}
}
