package com.urs.systems.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.urs.systems.dto.ProductDTO;
import com.urs.systems.model.User;
import com.urs.systems.repository.ProductRepository;
import com.urs.systems.repository.UserRepository;

@Service("ProductService")
public class ProductServiceImp implements ProductService {

	@Autowired
	ProductRepository productRepository;

	@Override
	public ProductDTO getProductByBarcode(String barcode) {
		return productRepository.getProductByBarcode(barcode);
	}
}
