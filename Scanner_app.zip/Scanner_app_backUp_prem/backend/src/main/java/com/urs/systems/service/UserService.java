package com.urs.systems.service;

import com.urs.systems.dto.UserDTO;
import com.urs.systems.model.User;

public interface UserService {

	User findUserByUsername(String username);

}
