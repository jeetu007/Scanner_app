package com.urs.systems.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import com.urs.systems.model.User;

@Service("customUserDetailsService")
public class CustomUserDetailsService implements UserDetailsService {

	@Autowired
	private UserServiceImp userService;

	@Override
	public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {

		User User = userService.findUserByUsername(username);

		if (User == null) {
			System.out.println("User not found");
			throw new UsernameNotFoundException("Username not found");
		}

		System.out.println("user : " + User.getFirstName());

		return new org.springframework.security.core.userdetails.User(User.getEmail(), User.getPassword(),
				User.getStatus().equalsIgnoreCase("Active"), true, true, true, getGrantedAuthorities(User));

	}

	private List<GrantedAuthority> getGrantedAuthorities(User User) {

		List<GrantedAuthority> authorities = new ArrayList<GrantedAuthority>();

		authorities.add(new SimpleGrantedAuthority("ROLE_" + User.getUserProfiles().get(0).getType()));

		System.out.print("authorities :" + authorities);

		return authorities;
	}

}
