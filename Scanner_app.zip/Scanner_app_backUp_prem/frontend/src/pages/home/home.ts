import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';
import { BarcodeScanner } from '@ionic-native/barcode-scanner';
import { ProductDetailsPage } from '../product-details/product-details';
import { AppConfigProvider } from '../../providers/app-config/app-config';
import { ToastController } from 'ionic-angular';
import { SQLite, SQLiteObject } from '@ionic-native/sqlite';
import { DeviceFeedback } from '@ionic-native/device-feedback';
import { CartDetailsPage } from '../cart-details/cart-details';
import { ServiceProvider } from '../../providers/service/service';

@Component({
  selector: 'page-home',
  templateUrl: 'home.html'
})
export class HomePage {

  barcodeText: any;
  showText: boolean;
  token: any;
  user: any;
  productdata: any;
  cartId: any;
  userId: any;
  userCart: any;
  totalQuantity: any;

  constructor(public navCtrl: NavController, private barcodeScanner: BarcodeScanner, public sqlite: SQLite,
    private data_service: AppConfigProvider, public toastCtrl: ToastController,
    private deviceFeedback: DeviceFeedback, public dataService: ServiceProvider) {

  }

  ionViewDidLoad() {
    this.showText = false;
    this.token = this.dataService.getUserInfo();
    console.log(this.token);

    if (this.token != null || this.token != undefined) {
      this.user = this.token.username;
      this.userId = this.token.uid;
      this.cartId = this.token.cartId;
    }
    this.getCartDetails(this.cartId);
  }

  /**
   * This method is used to get the current user cart details.
   * @author Premnath Christopher
   */
  fetchCurrrentUserCart() {
    this.dataService.getCurrentUserCart().then(
      (data) => {
        console.log("From Cart- > ", data);
        this.userCart = data;
        this.totalQuantity = this.userCart.totalQuantity;
      }
    ).catch((err) => {
      console.log(err);
    });
  }

  /**
   * This method is used to fetch the newly formed cart object from the backend.
   * This is called just after the user login to get the user cart.
   * @param id 
   * @author Premnath Christopher
   */
  getCartDetails(id) {
    this.dataService.getUserCart(id).subscribe(
      (res) => {
        if (res['qrCode'] === null) {
          res['qrCode'] = JSON.stringify({ "code_type": "QR-code", "delimiter": "$", "values": [] });
        }
        console.log(res);
        console.log(this.userId, this.cartId);
        localStorage.setItem("userCart", JSON.stringify(res));
        this.dataService.updateUserCart(JSON.stringify(res));
        this.fetchCurrrentUserCart();
      },
      (err) => {
        console.log(err);
      }
    )
  }

  /**
   * Keeps current user cart details ready on page enter.
   */
  ionViewDidEnter() {
    this.fetchCurrrentUserCart();
  }

  /**
   * Present a toast message.
   * @param mesg 
   */
  presentToast(mesg) {
    const toast = this.toastCtrl.create({
      message: mesg,
      duration: 3000,
      position: 'bottom',
      showCloseButton: true,
      closeButtonText: "X",
      dismissOnPageChange: true,
      cssClass: 'toasterClass'

    });

    toast.present();
  }

  /**
   * This method is used to scan the barcode and get the details of the product.
   * @author Premnath Christopher
   */
  scanBarcode() {
    this.barcodeScanner.scan().then((barcodeData) => {
      console.log(barcodeData);
      console.log(barcodeData.text + " |..| " + barcodeData.format + " |..| " + barcodeData.cancelled);
      this.barcodeText = barcodeData.text;
      this.showText = true;
      this.getProduct(this.barcodeText);
    }, (err) => {
      console.log(err);
    });
  }

  /**
   * This method is used to get one product via its product barcode.
   * @param barcode 
   * @author Premnath Christopher
   */
  getProduct(barcode) {
    this.dataService.fetchProduct(this.barcodeText).subscribe((res) => {
      this.productdata = res;
      let imageList = JSON.parse(this.productdata.imagePath);
      this.productdata.imagePath = imageList;
      console.log(this.productdata);
      this.navCtrl.push(ProductDetailsPage, { 'product': this.productdata });
    }, (err) => {
      console.log("Product Not Found !");
      console.log((err));
      this.presentToast("Product not found !");
    })
  }

  goToCart() {
    console.log("button clicked:");
    this.navCtrl.push(CartDetailsPage);
    // this.cart_length = 0;
  }

  logout() {
    console.log(this.token.access_token);
    this.dataService.logoutUser(this.token.access_token).subscribe(
      (res) => {
        console.log(res);
      },
      (err) => {
        console.log(err);
      }
    );
    this.navCtrl.popToRoot();
  }
}
