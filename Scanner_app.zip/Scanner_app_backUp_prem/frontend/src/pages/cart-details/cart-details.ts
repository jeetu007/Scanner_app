import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';
import { AppConfigProvider } from '../../providers/app-config/app-config';
import { SQLite, SQLiteObject } from '@ionic-native/sqlite';
import { OrderDetailPage } from '../order-detail/order-detail'
import { ServiceProvider } from '../../providers/service/service';
import { AlertController } from 'ionic-angular';


/**
 * Generated class for the CartDetailsPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@Component({
  selector: 'page-cart-details',
  templateUrl: 'cart-details.html',
})
export class CartDetailsPage {
  cart_table: string;
  cart_details: any = [];
  cart_length: number;
  total_price: number = 0;
  product_qty_price = 0;
  baseCloudUrl: any;
  //totalpricetoggle : boolean;
  charges: number = 0;
  qr_code: any;
  token: any;
  cartId: any;
  userCart: any;
  totalPrice: any;
  userCartDetail: any = [];


  constructor(public navCtrl: NavController, public navParams: NavParams, public data_service: AppConfigProvider,
    public sqlite: SQLite, public dataService: ServiceProvider,public alertCtrl: AlertController) {
    this.baseCloudUrl = this.data_service.getCloudUrl();
  }

  ionViewDidLoad() {
    //this.charges = this.navParams.get('delivery_charges');
    this.token = this.dataService.getUserInfo();
    if (this.token != null || this.token != undefined) {
      this.cartId = this.token.cartId;
    }
    this.fetchCurrrentUserCart();
  }

  ionViewDidEnter() {
  }

  goBack() {
    this.navCtrl.pop();
  }

  /**
   * This method is used to get the curren user cart information.
   */
  fetchCurrrentUserCart() {
    this.dataService.getCurrentUserCart().then(
      (data) => {
        this.userCart = data;
        this.totalPrice = data['totalPrice'];
        console.log("User Cart QR code values -> ", this.userCart.qrCode.values);
        this.getProductDetails();
      }
    ).catch((err) => {
      console.log(err);
    });
  }

  /**
   * Get the product details from qr code to display on the cart page with pictures
   * @author Premnath Christopher
   */
  getProductDetails() {
    this.userCart.qrCode = JSON.parse(this.userCart.qrCode);
    for (let i = 0; i < this.userCart.qrCode.values.length; i++) {
      this.dataService.fetchProduct(this.userCart.qrCode.values[i].barcode).subscribe(
        (response) => {
          console.log(response);
          response['imagePath'] = JSON.parse(response['imagePath']);
          this.userCartDetail.push(response);
          this.userCartDetail[i].itemQuantity = this.userCart.qrCode.values[i].quantity;
        },
        (error) => {
          console.log(error);
        }
      );
    }
    console.log(this.userCartDetail);
  }

  /**
   * This method is used to increase the quantity of the selected product
   * @param product 
   * @author Premnath Christopher
   */
  addQuantity(product) {
    //Sync with database
    console.log(product);
    for (let i = 0; i < this.userCart.qrCode.values.length; i++) {
      if (this.userCart.qrCode.values[i].barcode === product.barcode) {
        this.userCart.qrCode.values[i].quantity += 1;
        this.userCartDetail[i].itemQuantity = this.userCart.qrCode.values[i].quantity;
      }
    }
    console.log(this.userCart.qrCode.values);
    console.log(this.userCartDetail);
    this.updateCartNN();
  }

  /**
   * This method is used to decrease the quantity of the selected product
   * @param product 
   * @author Premnath Christopher
   */
  removeQuantiy(product) {
    //Sync with Backend 
    for (let i = 0; i < this.userCart.qrCode.values.length; i++) {
      if (this.userCart.qrCode.values[i].barcode === product.barcode) {
        if (this.userCart.qrCode.values[i].quantity > 1) {
          this.userCart.qrCode.values[i].quantity -= 1;
          this.userCartDetail[i].itemQuantity = this.userCart.qrCode.values[i].quantity;
        }
      }
    }
    console.log(this.userCart.qrCode.values);
    console.log(this.userCartDetail);
    this.updateCartNN();
  }

  /**
   * This method is used to remove the product from the cart.
   * @param product
   * @author Premnath Christopher 
   */
  removeProduct(product) {
    //Sync with Backend
    for (let i = 0; i < this.userCart.qrCode.values.length; i++) {
      if (this.userCart.qrCode.values[i].barcode === product.barcode) {
        this.userCart.qrCode.values.splice(i, 1);
      }
    }
    const index: number = this.userCartDetail.indexOf(product);
    this.userCartDetail.splice(index, 1);
    this.updateCartNN();
    console.log(this.userCart.qrCode.values);
  }

  /**
   * This method is used to buy all the items that have been added to cart.
   * The cart status becomes done once this method is called.
   * @author Premnath Christopher
   */
  buy() {
    this.userCart.status = "Done";
    this.userCart.qrCode = JSON.stringify(this.userCart.qrCode);
    this.dataService.updateCartNN(this.userCart).subscribe(
      (data) => {
        console.log(data);
        this.dataService.deleteUserCart();
        if (data['qrCode'] === null) {
          data['qrCode'] = JSON.stringify({ "code_type": "QR-code", "delimiter": "$", "values": [] });
        }
        this.dataService.updateUserCart(JSON.stringify(data));
      }, (err) => {
        console.log(err);
      }
    )
    this.navCtrl.push(OrderDetailPage, { 'qtyformat': JSON.stringify(this.userCart.qrCode) })
  }

  /**
   * This method is used to update the current cart status with that of the backend.
   * @author Premnath Christopher
   */
  updateCartNN() {
    this.userCart.qrCode = JSON.stringify(this.userCart.qrCode);
    this.dataService.updateCartNN(this.userCart).subscribe(
      (data) => {
        console.log(data);
        this.dataService.updateUserCart(JSON.stringify(data));
        this.getTotalPriceOfUserCart();
      }, (err) => {
        console.log(err);
      }
    )
  }

  /**
   * This method is used to get the current user cart details.
   */
  getTotalPriceOfUserCart() {
    this.dataService.getCurrentUserCart().then(
      (data) => {
        this.totalPrice = data['totalPrice'];
        this.userCart = data;
        this.userCart.qrCode = JSON.parse(this.userCart.qrCode);
      }
    ).catch((err) => {
      console.log(err);
    });
  }

  /**
   * This method is used to make sure the delete operation of oon selected product.
   * @param product 
   * @author Premnath Christopher
   */
  showDeleteConfirmation(product) {
    let confirm = this.alertCtrl.create({
      title: 'Are you sure to delete ?',
      buttons: [
        {
          text: 'No',
          handler: () => {
            console.log('Disagree clicked');
          }
        },
        {
          text: 'Yes',
          handler: () => {
            console.log('Agree clicked');
            this.removeProduct(product);
          }
        }
      ]
    });
    confirm.present();
  }
}
