import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';
import { LoadingController } from 'ionic-angular';
import { ServiceProvider } from '../../providers/service/service';


@Component({
  selector: 'user-page',
  templateUrl: 'user-page.html'
})
export class UserPage {

  token : any;
  user: any;
  constructor(public navCtrl: NavController, public loading: LoadingController,
    public dataService: ServiceProvider) {

  }

  ionViewDidLoad(){
    this.token = this.dataService.getUserInfo();
    this.user = this.token.user;
  }

  // testUser() {
  //   this.dataService.testUser().subscribe((res) => {
  //     console.log(res);
  //   }, (err) => {
  //     console.log((err));
  //   })
  // }
}
