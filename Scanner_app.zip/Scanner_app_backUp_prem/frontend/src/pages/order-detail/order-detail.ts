import { Component } from '@angular/core';
import { NavController, NavParams } from 'ionic-angular';
import { ToastController } from 'ionic-angular';
import { HomePage } from '../home/home';


@Component({
  selector: 'order-detail',
  templateUrl: 'order-detail.html'
})
export class OrderDetailPage {

  barcodeText: any;
  barcodeTextVariantTwo: any;

  constructor(public navCtrl: NavController, public navParams: NavParams,public toastCtrl: ToastController) {
    this.barcodeText = this.navParams.get("qtyformat");
    //this.barcodeTextVariantTwo = this.navParams.get("slashnformat");
  }

  ionViewDidLoad() {

  }

  goHome() {
    this.navCtrl.popTo(this.navCtrl.getByIndex(1));
  }

}
