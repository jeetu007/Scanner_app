import { Component } from '@angular/core';
import { NavController, NavParams } from 'ionic-angular';
import { AppConfigProvider } from '../../providers/app-config/app-config';
import { CartDetailsPage } from '../cart-details/cart-details';
import { SQLite, SQLiteObject } from '@ionic-native/sqlite';
import { ToastController } from 'ionic-angular';
import { DeviceFeedback } from '@ionic-native/device-feedback';
import { ServiceProvider } from '../../providers/service/service';


/**
 * Generated class for the ProductDetailsPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@Component({
  selector: 'page-product-details',
  templateUrl: 'product-details.html',
})
export class ProductDetailsPage {

  display_product: any = {};
  baseCloudUrl: string;
  finalAmount: any;
  cart_table: string;
  cart_details: any = [];
  cart_length: number;
  location: string = 'Bangalore'
  rate: any = 5
  netAmount: number;
  userCart: any;
  originalPrice: any;
  qr_code: any;
  token: any;
  userId: any;
  cartId: any;
  currentUsercart: any;
  totalQuantity: any;

  constructor(public navCtrl: NavController, public navParams: NavParams, public data_service: AppConfigProvider,
    public sqlite: SQLite, public toastCtrl: ToastController, private deviceFeedback: DeviceFeedback, public dataService: ServiceProvider) {
    this.baseCloudUrl = this.data_service.getCloudUrl();
  }

  /**
   * This method is used to present a toast message.
   * @param mesg 
   */
  presentToast(mesg) {
    const toast = this.toastCtrl.create({
      message: mesg,
      duration: 3000,
      position: 'bottom',
      showCloseButton: true,
      closeButtonText: "X",
      dismissOnPageChange: true,
      cssClass: 'toasterClass'

    });

    toast.present();
  }

  /**
   * This method loads for the once and keeps all the cart details ready.
   */
  ionViewDidLoad() {
    this.token = this.dataService.getUserInfo();

    this.display_product = this.navParams.get('product');
    if (this.display_product != null || this.display_product != undefined) {
      let discountPrice = (this.display_product.discount / 100) * this.display_product.price;
      this.netAmount = (this.display_product.price - discountPrice);
      this.originalPrice = this.display_product.price;
      console.log("Product >>> ", this.display_product);
    }
    if (this.token != null || this.token != undefined) {
      this.userId = this.token.uid;
      this.cartId = this.token.cartId;
    }
  }

  ionViewDidEnter() {
    //this.getProductLengthFromCart();
    this.fetchCurrentUserCart();
  }


  onModelChange(event) {
    console.log("event  >>>>", event);
  }

  /**
   * This method is used to fetch the current cart details of the user.
   */
  fetchCurrentUserCart() {
    console.log("Current User Cart Function...");
    this.dataService.getCurrentUserCart().then((data) => {
      this.currentUsercart = data;
      this.totalQuantity = this.currentUsercart.totalQuantity;
      console.log("Total Quantity", this.totalQuantity);
      console.log("Updated UserCart Table ->", this.currentUsercart);
    }).catch((err) => {
      console.log(err);
    });
  }

  goToCart() {
    console.log("button clicked:");
    // this.navCtrl.push(CartDetailsPage, {'delivery_charges': this.display_product.delivery_charges});
    this.navCtrl.push(CartDetailsPage);

    // this.cart_length = 0;
  }

  addToCart(display_product) {
    console.log(">>>>>>>>>>>>>>>>>>", display_product);
    this.display_product['price'] = this.netAmount
    console.log("------------------", display_product);
    this.addProductIntoCart(display_product);
    //this.getProductLengthFromCart();
    this.fetchCurrentUserCart();
    this.presentToast("Added to cart");
  }


/**
 * This method is used to add the products to the cart.
 * Increase the quantity if product is already present.
 * @param product 
 * @author Premnath Christopher
 */
  addProductIntoCart(product) {
    this.deviceFeedback.acoustic();
    this.deviceFeedback.haptic(0);
    console.log("USERCART - > ", this.currentUsercart);
    this.currentUsercart.qrCode = JSON.parse(this.currentUsercart.qrCode);
    if (this.currentUsercart.qrCode.values.length == 0 || this.currentUsercart.qrCode.values.length == null || this.currentUsercart.qrCode.values.length == undefined) {
      this.add(product)
    } else {
      for (let i = 0; i < this.currentUsercart.qrCode.values.length; i++) {
        if (this.currentUsercart.qrCode.values[i].barcode === product.barcode) {
          this.updateProductQty(this.currentUsercart.qrCode.values[i]);
          return;
        }
      }
      this.add(product);
    }
  }

/**
 * This method is used to update the quantity of the product already present.
 * @param product 
 * @author Premnath Christopher
 */
  updateProductQty(product) {
    //Sync with backend
    console.log(product);
    console.log(this.currentUsercart);
    const index: number = this.currentUsercart.qrCode.values.indexOf(product);
    if (index !== -1) {
      this.currentUsercart.qrCode.values[index].quantity += 1;
    }
    this.currentUsercart.qrCode = JSON.stringify(this.currentUsercart.qrCode);
    this.dataService.updateCartNN(this.currentUsercart).subscribe(
      (res) => {
        console.log(res);
        this.dataService.updateUserCart(JSON.stringify(res));
        this.fetchCurrentUserCart();
      }, (err) => {
        console.log(err);
      }
    );
  }

  /**
   * Add the product to the generated QR code if not already present.
   * @param product 
   * @author Premnath Christopher
   */
  add(product) {
    //Sync with backend
    console.log(this.currentUsercart);
    this.currentUsercart.qrCode.values.push({
      "barcode": product.barcode,
      "product_id": product.productId,
      "quantity": product.quantity
    });

    this.currentUsercart.qrCode = JSON.stringify(this.currentUsercart.qrCode);
    this.dataService.updateCartNN(this.currentUsercart).subscribe(
      (res) => {
        console.log(res);
        this.dataService.updateUserCart(JSON.stringify(res));
        this.currentUsercart = res;
        this.fetchCurrentUserCart();
      }, (err) => {
        console.log(err);
      }
    );
  }

  /**
   * This method is used to get the cart from backend and sync it with the SqlLite cart table for related fields.
   */
  updateUserCart() {
    for (let i = 0; i < this.cart_details.length; i++) {
      this.qr_code.values =
        [{
          "barcode": this.cart_details[i].barcode,
          "product_id": this.cart_details[i].product_id,
          "quantity": this.cart_details[i].quantity
        }];
    }
    console.log("USERCart", this.userCart);
    this.userCart.qrCode = JSON.stringify(this.qr_code);
    // console.log("SqlLite", this.cart_details);
    console.log("QR->", this.qr_code);
    console.log("Cart", this.userCart);
    this.dataService.updateCartNN(this.userCart).subscribe(
      (res) => {
        console.log(res);
      }, (err) => {
        console.log(err);
      }
    );

  }

  getProductLengthFromCart() {
    this.cart_table = this.data_service.getCartTable();
    this.sqlite.create({ name: 'data.db', location: 'default' })
      .then((db: SQLiteObject) => {
        db.executeSql('select * from ' + this.cart_table, {})
          .then((data) => {
            // this.cart_length = data.rows.length
            this.cart_length = 0

            this.cart_details = [];
            for (let i = 0; i < data.rows.length; i++) {
              this.cart_length += data.rows.item(i).quantity;
              this.cart_details.push(data.rows.item(i))
            }
            this.updateUserCart();
          }).catch(e => console.log(e));
      }).catch(e => console.log(e));
  }

  addAnotherProduct() {
    this.navCtrl.pop();
  }



}
