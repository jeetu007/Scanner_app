import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';
import { AlertController } from 'ionic-angular';
import { LoadingController } from 'ionic-angular';
import { ServiceProvider } from '../../providers/service/service';
import { UserPage } from '../../pages/user-page/user-page';
import { HomePage } from '../../pages/home/home';



@Component({
  selector: 'login',
  templateUrl: 'login.html'
})
export class LoginPage {

  username: any;
  constructor(public navCtrl: NavController, public alertCtrl: AlertController, public loading: LoadingController,
    public dataService: ServiceProvider) {

  }

  /**
   * This is the alert login box.
   */
  login() {
    let prompt = this.alertCtrl.create({
      title: 'Login',
      inputs: [
        {
          name: 'Username',
          placeholder: 'Enter Username'
        },
        {
          name: 'Password',
          placeholder: 'Enter Password',
          type: 'password'
        }
      ],
      buttons: [
        {
          text: 'Cancel',
          handler: data => {
            console.log('Cancel clicked');
          }
        },
        {
          text: 'Login',
          handler: data => {
            this.doUserLogin(data.Username, data.Password);
          }
        }
      ]
    });
    prompt.present();
  }

  doUserLogin(username, password) {
    this.username = username;
    console.log("Login Username - " + this.username, "password- " + password);

    let loader = this.loading.create({
      content: 'Logging in...',
      dismissOnPageChange: true
    });
    loader.present().then(() => {
      this.dataService.doLogin(username, password).subscribe(
        (res) => {
          console.log(res);
          loader.dismiss();
          localStorage.setItem("access_token",res.access_token);
          this.dataService.setUserInfo(JSON.stringify(res));
          this.navCtrl.push(HomePage);
          
        },
        (err) => {
          console.log(err);
          loader.dismiss();
        }
      )
    });
  }

}
