import { Injectable } from '@angular/core';
import 'rxjs/add/operator/map';
import { SQLite, SQLiteObject } from '@ionic-native/sqlite';

/*
  Generated class for the AppConfigProvider provider.

  See https://angular.io/guide/dependency-injection for more info on providers
  and Angular DI.
*/
@Injectable()
export class AppConfigProvider {


  public user_cart_table = 'user_cart';
  public baseCloudUrl = 'https://storage.googleapis.com/image-video/';
  public cart_table = "product_cart"
  cart_details: any = [];
  cart_length: number;
  allProducts: any;

  constructor(public sqlite: SQLite, ) {

  }

  getUserCartTable() {
    return this.user_cart_table;
  }

  getCloudUrl() {
    return this.baseCloudUrl;
  }

  setCartDetails(product) {
    this.cart_details.push(product)
  }

  getCartDetails() {
    return this.cart_details
  }

  getCartLength() {
    this.cart_length = this.cart_details.length
    return this.cart_length
  }

  getCartTable() {
    return this.cart_table
  }

}
