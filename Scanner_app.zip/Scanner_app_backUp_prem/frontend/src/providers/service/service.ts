import { HttpClient, HttpParams, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs/Rx';
import { SQLite, SQLiteObject } from '@ionic-native/sqlite';
import { AppConfigProvider } from '../../providers/app-config/app-config';

/*
  Generated class for the ServiceProvider provider.

  See https://angular.io/guide/dependency-injection for more info on providers
  and Angular DI.
*/
@Injectable()
export class ServiceProvider {

  baseUrl = "http://35.202.131.197/bcodeApp/";
  public clientId = 'my-trusted-client';
  public clientSecret = 'secret';
  public userInfo: any;
  cart_table: string;
  cart_details: any = [];
  cart_length: number;
  userCartTable: any;
  updatedUserCart: any;

  constructor(public http: HttpClient, public appConfig: AppConfigProvider, public sqlite: SQLite, ) {
    console.log('Hello ServiceProvider Provider');
    this.userCartTable = this.appConfig.getUserCartTable();
  }

  doLogin(username, password): Observable<any> {
    console.log("service Login - " + username, password);

    let Params = new HttpParams();
    // Begin assigning parameters
    Params = Params.append('grant_type', 'password');
    Params = Params.append('username', username);
    Params = Params.append('password', password);

    return this.http.post(this.baseUrl + 'oauth/token', {}, {
      headers: new HttpHeaders().set('Authorization', "Basic " + btoa(this.clientId + ":" + this.clientSecret)),
      params: Params
    });
  }

  setUserInfo(response) {
    this.userInfo = JSON.parse(response);
  }

  getUserInfo(): any {
    return this.userInfo;
  }

  fetchProduct(barcode) {
    return this.http.get(this.baseUrl + 'user/product/' + barcode);
  }

  getUserCart(id) {
    return this.http.get(this.baseUrl + 'user/cart/' + id);
  }


  deleteUserCart() {
    let query = "DELETE FROM " + this.userCartTable;
    this.sqlite.create({
      name: 'data.db',
      location: 'default'
    })
      .then((db: SQLiteObject) => {
        db.executeSql(query, {})
          .then((data) => {
            console.log('Executed SQL...Data Deleted From UserCartTable...');
          })
          .catch(e => console.log('Error.' + JSON.stringify(e)));
      })
      .catch(e => console.log(JSON.stringify(e)));
  }


  updateUserCart(cart) {
    let updatedCart = JSON.parse(cart);
    console.log("Incoming Updated Cart - > ", updatedCart);
    let qrCode = updatedCart.qrCode;
    console.log(qrCode);
    this.sqlite.create({
      name: 'data.db',
      location: 'default'
    }).then((db: SQLiteObject) => {
      db.executeSql('INSERT INTO ' + this.userCartTable + '(cartId, deliveryCharge, discount, qrCode, status, tax, totalPrice, totalQuantity) VALUES(?,?,?,?,?,?,?,?)',
        [updatedCart.cartId, updatedCart.deliveryCharge, updatedCart.discount, updatedCart.qrCode, updatedCart.status, updatedCart.tax, updatedCart.totalPrice, updatedCart.totalQuantity])
        .then(() => {
          console.log('UserCart table is updated..............')
        })
        .catch(e => { console.log('user cart data is not inserted ..............'); console.log(e) });
    }).catch(e => console.log('user cart data is not inserted ..............'));
  }

  /**This method is used to get the current user cart.  */
  getCurrentUserCart(): any {
    this.updatedUserCart = null;
    return new Promise((resolve, reject) => {
      this.sqlite.create({ name: 'data.db', location: 'default' })
        .then((db: SQLiteObject) => {
          db.executeSql('select * from ' + this.userCartTable, {})
            .then((data) => {
              if (data.rows.length > 0) {
                this.updatedUserCart = data.rows.item(data.rows.length - 1);
                resolve(this.updatedUserCart);
              } else {
                reject(this.updatedUserCart);
              }
            }).catch(e => reject(e));
        }).catch(e => reject(e));
    });
  }

/**
 * This method is used to update the cart details of the currently logged in user.
 * @param userCart 
 */
  updateCartNN(userCart) {
    console.log("Cart Sent to Backend - > ", userCart);
    return this.http.put(this.baseUrl + 'user/cartnn', userCart);
  }

  logoutUser(access_token){
    console.log("Logout - > ", access_token);
    let Params = new HttpParams();
    Params = Params.append('access_token', access_token);
    return this.http.post(this.baseUrl+'all/logout',{},{params: Params});
  }

}
