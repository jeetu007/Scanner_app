import { BrowserModule } from '@angular/platform-browser';
import { ErrorHandler, NgModule } from '@angular/core';
import { IonicApp, IonicErrorHandler, IonicModule } from 'ionic-angular';
import { SplashScreen } from '@ionic-native/splash-screen';
import { StatusBar } from '@ionic-native/status-bar';
import { HttpClientModule} from '@angular/common/http';
import { HTTP_INTERCEPTORS } from '@angular/common/http';
import { TokenInterceptor } from '../providers/TokenInterceptor/token-interceptor';
import { ServiceProvider } from '../providers/service/service';

import { BarcodeScanner } from '@ionic-native/barcode-scanner';
import { NgxQRCodeModule } from 'ngx-qrcode2';
import { SQLite } from '@ionic-native/sqlite';
import { Ionic2RatingModule } from 'ionic2-rating';
import { DeviceFeedback } from '@ionic-native/device-feedback';

import { MyApp } from './app.component';
import { HomePage } from '../pages/home/home';
import { UserPage } from '../pages/user-page/user-page';

import { LoginPage } from '../pages/login/login';
import { OrderDetailPage } from '../pages/order-detail/order-detail';
import { ProductDetailsPage } from '../pages/product-details/product-details';
import { AppConfigProvider } from '../providers/app-config/app-config';
import { CartDetailsPage } from '../pages/cart-details/cart-details';

@NgModule({
  declarations: [
    MyApp,
    LoginPage,    
    HomePage,
    UserPage,
    OrderDetailPage,
    ProductDetailsPage,
    CartDetailsPage
  ],
  imports: [
    BrowserModule,HttpClientModule,
    NgxQRCodeModule,    
    Ionic2RatingModule,
    IonicModule.forRoot(MyApp)
  ],
  bootstrap: [IonicApp],
  entryComponents: [
    MyApp,
    LoginPage,    
    HomePage,
    OrderDetailPage,
    ProductDetailsPage,
    CartDetailsPage
  ],
  providers: [
    {
      provide: HTTP_INTERCEPTORS,
      useClass: TokenInterceptor,
      multi: true
    },
    StatusBar,ServiceProvider,
    SplashScreen,BarcodeScanner,SQLite,AppConfigProvider,DeviceFeedback,
    {provide: ErrorHandler, useClass: IonicErrorHandler}
  ]
})
export class AppModule {}
