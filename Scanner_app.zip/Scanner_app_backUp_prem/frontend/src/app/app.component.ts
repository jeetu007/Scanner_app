import { Component } from '@angular/core';
import { Platform } from 'ionic-angular';
import { StatusBar } from '@ionic-native/status-bar';
import { SplashScreen } from '@ionic-native/splash-screen';
import { SQLite, SQLiteObject } from '@ionic-native/sqlite';
import { AppConfigProvider } from '../providers/app-config/app-config';

import { LoginPage } from '../pages/login/login';
import { HomePage } from '../pages/home/home';

@Component({
  templateUrl: 'app.html'
})
export class MyApp {
  rootPage: any = LoginPage;
  public productTable: any;
  public imageTable: any;
  cart_table: string;
  public userCartTable: any;

  constructor(platform: Platform, statusBar: StatusBar, splashScreen: SplashScreen, private sqlite: SQLite,
    private appConfig: AppConfigProvider) {

    this.userCartTable = this.appConfig.getUserCartTable();
    platform.ready().then(() => {
      // Okay, so the platform is ready and our plugins are available.
      // Here you can do any higher level native things you might need.
      //---
      // this.sqlite.create({
      //   name: 'data.db',
      //   location: 'default'
      // })
      //   .then((db: SQLiteObject) => {
      //     db.executeSql('DROP TABLE ' + this.cart_table, {})
      //       .then(() => console.log('>>> drop cart table.. -'))
      //       .catch(e => console.log("error while drop cart table - " + e));

      //     db.executeSql('DROP TABLE ' + this.userCartTable, {})
      //       .then(() => console.log('>>> drop cart table.. -'))
      //       .catch(e => console.log("error while drop cart table - " + e));
      //   })

      //   .catch(e => console.log(e));
      
      //----
        this.sqlite.create({
          name: 'data.db',
          location: 'default'
        })
          .then((db: SQLiteObject) => {
            db.executeSql('CREATE TABLE IF NOT EXISTS ' + this.userCartTable + ' (id INTEGER PRIMARY KEY AUTOINCREMENT, cartId INTEGER,deliveryCharge TEXT,discount TEXT, qrCode TEXT, status TEXT , tax TEXT, totalPrice TEXT, totalQuantity INTEGER)', {})
              .then(() => console.log('>>> userCart Table is created -'))
              .catch(e => console.log(">>> Error in userCart Table creation - " + e));
          })
          .catch(e => console.log(e));
        //----
      statusBar.backgroundColorByName('purple');
      splashScreen.hide();
    });
  }
}

