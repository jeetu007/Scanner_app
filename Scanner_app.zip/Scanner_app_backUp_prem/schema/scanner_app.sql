/*
SQLyog Ultimate v11.11 (64 bit)
MySQL - 5.7.14-log : Database - barcode_app
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
CREATE DATABASE /*!32312 IF NOT EXISTS*/`barcode_app` /*!40100 DEFAULT CHARACTER SET utf8 */;

USE `barcode_app`;

/*Table structure for table `cart` */

DROP TABLE IF EXISTS `cart`;

CREATE TABLE `cart` (
  `cart_id` int(11) NOT NULL AUTO_INCREMENT,
  `created_on` datetime DEFAULT NULL,
  `delivery_charge` double DEFAULT NULL,
  `discount` double DEFAULT NULL,
  `modified_on` datetime DEFAULT NULL,
  `qr_code` varchar(255) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `tax` double DEFAULT NULL,
  `total_price` double DEFAULT NULL,
  `total_quantity` int(11) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`cart_id`),
  KEY `FKl70asp4l4w0jmbm1tqyofho4o` (`user_id`),
  CONSTRAINT `FKl70asp4l4w0jmbm1tqyofho4o` FOREIGN KEY (`user_id`) REFERENCES `user` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=utf8;

/*Data for the table `cart` */

insert  into `cart`(`cart_id`,`created_on`,`delivery_charge`,`discount`,`modified_on`,`qr_code`,`status`,`tax`,`total_price`,`total_quantity`,`user_id`) values (3,'2017-11-20 11:55:28',139,20.2,'2017-11-20 12:22:20','{\"code_type\":\"QR-code\",\"delimiter\":\"$\",\"values\":[{\"barcode\":\"201234567899\",\"product_id\":1,\"quantity\":2},{\"barcode\":\"512345000107\",\"product_id\":2,\"quantity\":3}]}','Done',10.11,52460,5,1),(4,'2017-11-20 12:22:20',139,20.2,'2017-11-20 12:28:29','{\"code_type\":\"QR-code\",\"delimiter\":\"$\",\"values\":[{\"barcode\":\"201234567899\",\"product_id\":1,\"quantity\":1}]}','Done',10.11,11230,1,1),(5,'2017-11-20 12:28:29',139,20.2,'2017-11-20 16:07:13','{\"code_type\":\"QR-code\",\"delimiter\":\"$\",\"values\":[{\"barcode\":\"201234567899\",\"product_id\":1,\"quantity\":5}]}','Done',10.11,56150,5,1),(6,'2017-11-20 16:02:15',139,20.2,'2017-11-20 16:59:38','{\"code_type\":\"QR-code\",\"delimiter\":\"$\",\"values\":[{\"barcode\":\"201234567899\",\"product_id\":1,\"quantity\":3},{\"barcode\":\"512345000107\",\"product_id\":2,\"quantity\":3}]}','Done',10.11,63690,6,1),(7,'2017-11-20 16:37:06',139,20.2,'2017-11-20 17:08:15','{\"code_type\":\"QR-code\",\"delimiter\":\"$\",\"values\":[{\"barcode\":\"512345000107\",\"product_id\":2,\"quantity\":3}]}','Done',10.11,30000,3,1),(8,'2017-11-20 17:08:15',139,20.2,'2017-11-20 17:39:48','{\"code_type\":\"QR-code\",\"delimiter\":\"$\",\"values\":[{\"barcode\":\"512345000107\",\"product_id\":2,\"quantity\":4}]}','Done',10.11,40000,4,1),(9,'2017-11-20 17:39:48',139,20.2,'2017-11-22 13:00:02','{\"code_type\":\"QR-code\",\"delimiter\":\"$\",\"values\":[{\"barcode\":\"201234567899\",\"product_id\":1,\"quantity\":5}]}','Done',10.11,56150,5,1),(10,'2017-11-22 13:00:02',139,20.2,'2017-11-22 13:20:49','{\"code_type\":\"QR-code\",\"delimiter\":\"$\",\"values\":[{\"barcode\":\"201234567899\",\"product_id\":1,\"quantity\":1},{\"barcode\":\"512345000107\",\"product_id\":2,\"quantity\":1}]}','Done',10.11,21230,2,1),(11,'2017-11-22 13:05:45',139,20.2,'2017-11-22 13:10:51','{\"code_type\":\"QR-code\",\"delimiter\":\"$\",\"values\":[{\"barcode\":\"201234567899\",\"product_id\":1,\"quantity\":2}]}','Done',10.11,22460,2,1),(12,'2017-11-22 13:10:51',139,20.2,'2017-11-22 13:12:37','{\"code_type\":\"QR-code\",\"delimiter\":\"$\",\"values\":[{\"barcode\":\"201234567899\",\"product_id\":1,\"quantity\":2},{\"barcode\":\"512345000107\",\"product_id\":2,\"quantity\":2}]}','Done',10.11,42460,4,1),(13,'2017-11-22 13:12:37',139,20.2,'2017-11-22 13:13:23','{\"code_type\":\"QR-code\",\"delimiter\":\"$\",\"values\":[{\"barcode\":\"512345000107\",\"product_id\":2,\"quantity\":3},{\"barcode\":\"201234567899\",\"product_id\":1,\"quantity\":1}]}','Done',10.11,41230,4,1),(14,'2017-11-22 13:13:23',139,20.2,'2017-11-22 13:22:01','{\"code_type\":\"QR-code\",\"delimiter\":\"$\",\"values\":[{\"barcode\":\"512345000107\",\"product_id\":2,\"quantity\":1},{\"barcode\":\"201234567899\",\"product_id\":1,\"quantity\":1}]}','Done',10.11,21230,2,1),(15,'2017-11-22 13:22:01',139,20.2,'2017-11-22 13:31:28','{\"code_type\":\"QR-code\",\"delimiter\":\"$\",\"values\":[{\"barcode\":\"201234567899\",\"product_id\":1,\"quantity\":3}]}','Done',10.11,33690,3,1),(16,'2017-11-22 13:23:03',139,20.2,'2017-11-22 13:34:14','{\"code_type\":\"QR-code\",\"delimiter\":\"$\",\"values\":[{\"barcode\":\"201234567899\",\"product_id\":1,\"quantity\":10}]}','Done',10.11,112300,10,1),(17,'2017-11-22 13:34:14',139,20.2,'2017-11-22 13:35:17','{\"code_type\":\"QR-code\",\"delimiter\":\"$\",\"values\":[{\"barcode\":\"512345000107\",\"product_id\":2,\"quantity\":2},{\"barcode\":\"201234567899\",\"product_id\":1,\"quantity\":3}]}','Done',10.11,53690,5,1),(18,'2017-11-22 13:35:17',139,20.2,'2017-11-22 13:35:39','{\"code_type\":\"QR-code\",\"delimiter\":\"$\",\"values\":[{\"barcode\":\"201234567899\",\"product_id\":1,\"quantity\":1}]}','Done',10.11,11230,1,1),(19,'2017-11-22 13:35:39',0,0,'2017-11-22 13:35:39',NULL,'Pending',0,0,0,1);

/*Table structure for table `product` */

DROP TABLE IF EXISTS `product`;

CREATE TABLE `product` (
  `product_id` int(11) NOT NULL AUTO_INCREMENT,
  `barcode` varchar(255) DEFAULT NULL,
  `brand_name` varchar(255) DEFAULT NULL,
  `created_on` datetime DEFAULT NULL,
  `discount` double DEFAULT NULL,
  `model_name` varchar(255) DEFAULT NULL,
  `modified_on` datetime DEFAULT NULL,
  `price` double DEFAULT NULL,
  `quantity` int(11) DEFAULT NULL,
  `tax` int(11) DEFAULT NULL,
  `images_path` varchar(600) DEFAULT NULL,
  PRIMARY KEY (`product_id`),
  UNIQUE KEY `UK_44c6umvphppa3226vhmagmviu` (`barcode`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

/*Data for the table `product` */

insert  into `product`(`product_id`,`barcode`,`brand_name`,`created_on`,`discount`,`model_name`,`modified_on`,`price`,`quantity`,`tax`,`images_path`) values (1,'201234567899','A1','2017-11-14 16:43:18',10,'prop','2017-11-14 16:43:33',11230,1,10,'[{\"base_url\":\"https://storage.googleapis.com/image-video/\",\"images\":[{\"path\":\"abc\",\"name\":\"property-07f940fa-2377-ea26-d8b6-f49aee331ac0.jpg\",\"width\":\"250\",\"height\":\"400\"},{\"path\":\"xyz\",\"name\":\"property-142731a9-f35f-93a6-9b26-42b8c0c0c58f.jpg\",\"width\":\"350\",\"height\":\"600\"}]}]'),(2,'512345000107','B1','2017-11-14 16:43:18',20,'Property','2017-11-14 16:43:33',10000,1,10,'[{\"base_url\":\"https://storage.googleapis.com/image-video/\",\"images\":[{\"path\":\"abc\",\"name\":\"property-07f940fa-2377-ea26-d8b6-f49aee331ac0.jpg\",\"width\":\"250\",\"height\":\"400\"},{\"path\":\"xyz\",\"name\":\"property-142731a9-f35f-93a6-9b26-42b8c0c0c58f.jpg\",\"width\":\"350\",\"height\":\"600\"}]}]');

/*Table structure for table `product_image` */

DROP TABLE IF EXISTS `product_image`;

CREATE TABLE `product_image` (
  `product_image_id` int(11) NOT NULL AUTO_INCREMENT,
  `created_on` datetime DEFAULT NULL,
  `height` varchar(255) DEFAULT NULL,
  `images_path` varchar(255) DEFAULT NULL,
  `modified_on` datetime DEFAULT NULL,
  `width` varchar(255) DEFAULT NULL,
  `product_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`product_image_id`),
  KEY `FK6oo0cvcdtb6qmwsga468uuukk` (`product_id`),
  CONSTRAINT `FK6oo0cvcdtb6qmwsga468uuukk` FOREIGN KEY (`product_id`) REFERENCES `product` (`product_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `product_image` */

/*Table structure for table `user` */

DROP TABLE IF EXISTS `user`;

CREATE TABLE `user` (
  `user_id` int(11) NOT NULL AUTO_INCREMENT,
  `created_on` datetime DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `first_name` varchar(255) DEFAULT NULL,
  `last_name` varchar(255) DEFAULT NULL,
  `mobile` varchar(255) DEFAULT NULL,
  `modified_on` datetime DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `username` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`user_id`),
  UNIQUE KEY `UK_sb8bbouer5wak8vyiiy4pf2bx` (`username`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

/*Data for the table `user` */

insert  into `user`(`user_id`,`created_on`,`email`,`first_name`,`last_name`,`mobile`,`modified_on`,`password`,`status`,`username`) values (1,'2017-11-14 14:49:27','abc','Prem','Chris','9693','2017-11-14 14:49:48','12345','active','prem'),(2,'2017-11-14 14:49:27','abc','Chris','Prem','9693','2017-11-14 14:49:48','12345','active','chris');

/*Table structure for table `user_profile` */

DROP TABLE IF EXISTS `user_profile`;

CREATE TABLE `user_profile` (
  `user_profile_id` int(11) NOT NULL AUTO_INCREMENT,
  `created_on` datetime DEFAULT NULL,
  `modified_on` datetime DEFAULT NULL,
  `type` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`user_profile_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

/*Data for the table `user_profile` */

insert  into `user_profile`(`user_profile_id`,`created_on`,`modified_on`,`type`) values (1,'2017-11-14 14:50:38','2017-11-14 14:50:41','USER'),(2,'2017-11-14 14:50:38','2017-11-14 14:50:41','ADMIN');

/*Table structure for table `user_user_profile` */

DROP TABLE IF EXISTS `user_user_profile`;

CREATE TABLE `user_user_profile` (
  `user_id` int(11) NOT NULL,
  `user_profile_id` int(11) NOT NULL,
  KEY `FK65jbbj4ob6ayaew7fn6ociiki` (`user_profile_id`),
  KEY `FK43m7kfha0ucyod582xewxgsa2` (`user_id`),
  CONSTRAINT `FK43m7kfha0ucyod582xewxgsa2` FOREIGN KEY (`user_id`) REFERENCES `user` (`user_id`),
  CONSTRAINT `FK65jbbj4ob6ayaew7fn6ociiki` FOREIGN KEY (`user_profile_id`) REFERENCES `user_profile` (`user_profile_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `user_user_profile` */

insert  into `user_user_profile`(`user_id`,`user_profile_id`) values (1,1),(2,1);

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
